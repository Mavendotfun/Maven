# Nosana Common

The Nosana Common crate can be found under [./common](common).
The crate holds a number of re-usable components that are used throughout other Nosana programs.
These components include:

- IDs
- ErrorCodes
- Utility functions
- Macros
- Constant Values
