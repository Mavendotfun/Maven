## Diagram

```mermaid
flowchart TB
    authority -->|register<br>update| node

    authority(Node Authority)
    node{Node Account}

    classDef orange fill:#f96,stroke:#333,stroke-width:3px;

    class stake orange
```
